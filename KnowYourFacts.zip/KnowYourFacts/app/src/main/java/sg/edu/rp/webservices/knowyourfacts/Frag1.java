package sg.edu.rp.webservices.knowyourfacts;


import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.Random;


/**
 * A simple {@link Fragment} subclass.
 */
public class Frag1 extends Fragment {
Button btnChange;
LinearLayout ll;
ArrayList<Integer> alColor;
Integer num;

    public Frag1() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_1, container, false);
        // Inflate the layout for this fragment
        alColor = new ArrayList<Integer>();
        alColor.add(Color.RED);
        alColor.add(Color.BLUE);
        alColor.add(Color.GREEN);
        alColor.add(Color.CYAN);
        alColor.add(Color.DKGRAY);
        alColor.add(Color.GRAY);
        alColor.add(Color.LTGRAY);
        alColor.add(Color.MAGENTA);
        alColor.add(Color.YELLOW);
        btnChange = v.findViewById(R.id.buttonC1);
        ll = v.findViewById(R.id.linearLayout1);

        ll.setBackgroundColor(Color.RED);
        btnChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random r = new Random();
                num = r.nextInt(9);
                ll.setBackgroundColor(alColor.get(num));
            }
        });
        return v;
    }

}
