package sg.edu.rp.webservices.knowyourfacts;


import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.Random;


/**
 * A simple {@link Fragment} subclass.
 */
public class Frag3 extends Fragment {
ArrayList<Integer> alColor;
    Button btnChange;
    LinearLayout ll;
    Integer num;

    public Frag3() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_3, container, false);
        // Inflate the layout for this fragment
        alColor = new ArrayList<Integer>();
        alColor.add(Color.RED);
        alColor.add(Color.BLUE);
        alColor.add(Color.GREEN);
        alColor.add(Color.CYAN);
        alColor.add(Color.DKGRAY);
        alColor.add(Color.GRAY);
        alColor.add(Color.LTGRAY);
        alColor.add(Color.MAGENTA);
        alColor.add(Color.YELLOW);
        btnChange = v.findViewById(R.id.buttonC3);
        ll = v.findViewById(R.id.linearLayout3);

        ll.setBackgroundColor(Color.YELLOW);
        btnChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random r = new Random();
                num = r.nextInt(9);
                ll.setBackgroundColor(alColor.get(num));
            }
        });
        return v;
    }

}
